document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting

    const eventName = document.getElementById('eventSelect').value;
    const userName = document.getElementById('userName').value.trim();

    if (!eventName || !userName) {
        alert('Please select an event and enter your name.');
        return;
    }

    const listId = eventName.toLowerCase().replace(' ', '') + 'List'; // Construct the list ID
    const listElement = document.getElementById(listId);

    // Create a new list item with the user's name
    const listItem = document.createElement('li');
    listItem.textContent = userName;
    listElement.appendChild(listItem);

    // Clear the input field
    document.getElementById('userName').value = '';
});
