import React from "react";
import axios from "axios";


function App() {
  var [user,setUser] = React.useState('');
  var [pass,setPass] = React.useState('');
  var [enter,setEnter] = React.useState(true);
  var [arr,setArr] = React.useState([{username:"tarak",password:"tsrk7781@vk",description:"awesome project"},{username:"saikoppineni",password:"saikoppineni1891@vk",description:"hello everyone,this is a project given by IIDT blackbucks"},{username:"chawla",password:"chawla0809@ch",description:"chawla is a good person"},{username:"bajji",password:"bajji0705@07",description:"bajji is a excellent bowler"},{username:"virat",password:"kohli0302@02",description:"kohli is a good batter and nice person"}]);
  // var arr = [];
  function userChange(event){
    setUser(event.target.value)
  }
  function passChange(event){
    setPass(event.target.value)
  }
  async function formSubmit(event){
    event.preventDefault();
    await axios.get("http://localhost:8090/api/notes/",{
      params:{
      mainuser:user,
      mainpass:pass,
      }
    },{
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    }).then((res)=>{
        setArr(res.data)
        console.log(arr[0]);
        setEnter(true)
    })
    .catch((e)=>{
      setArr([])
      setEnter(true)})
  }

  var [user1,setUser1] = React.useState("");
  var [pass1,setPass1] = React.useState("");
  var [msg,setMsg] = React.useState("");
  function user1Change(event){
    setUser1(event.target.value)
  }
  function pass1Change(event){
    setPass1(event.target.value)
  }
  function msgChange(event){
    setMsg(event.target.value)
  }
  async function dataSubmit(event){
    event.preventDefault();
    await axios.post("http://localhost:8090/api/notes/",JSON.stringify({
      mainuser:user,
      mainpass:pass,
      username:user1,
      password:pass1,
      description:msg
    }),{
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    }).then((res)=>{
      console.log(res.data)
      setEnter(false)
    })
    .catch((err)=>console.log(err))
    setUser("")
    setPass("")
    setUser1("")
    setPass1("")
    setMsg("")
  }

  return(
  (!enter) ?<div>
    <form onSubmit={formSubmit}>
      <label htmlFor="userid">Enter Username</label>
      <input required type="text" placeholder="Enter username" id="userid" name="userid" value={user} onChange={userChange} />
      <label htmlFor="passid">Enter password</label>
      <input required type="password" placeholder="Enter Password" id="passid" name="passid" value={pass} onChange={passChange} />
      <button type="submit">submit</button>
    </form>
  </div>
  :<div id="">
    <div id="">
      {arr.map(item=>(
        <div className="">
        <p className="">username:{item.username}</p>
        <p className="">password:{item.password}</p>
        <p className="">description:{item.description}</p>
        </div>))}
    </div>
    <form onSubmit={dataSubmit} id="">
      <h1 id="">Enter details to be stored</h1>
      <label id="" htmlFor="userid1">Enter username</label>
      <input required type="text" placeholder="Enter username" id="userid1" name="userid1" value={user1} onChange={user1Change} />
      <label id="" htmlFor="passid1">Enter password</label>
      <input required type="password" placeholder="Enter Password" id="passid1" name="passid1" value={pass1} onChange={pass1Change} />
      <label id="" htmlFor="msgid">Enter message</label>
      <input type="text" placeholder="Enter message" id="msgid" name="msgid" value={msg} onChange={msgChange} />
      <button id="" type="submit">submit</button>
    </form>
  </div>
  )
}

export default App;
